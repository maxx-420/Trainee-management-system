package com.cg.tms.service;

import java.util.List;

import com.cg.tms.entities.Trainee;

public interface TraineeService {

	public void addTrainee(Trainee trainee);
	public int delTrainee(int traineeId);
	public Trainee modifyTrainee(Trainee trainee);
	public Trainee viewOne(int traineeId);
	public List<Trainee> viewAll();
}
