package com.cg.tms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.cg.tms.dao.TraineeDao;
import com.cg.tms.entities.Trainee;
@Service("tser")
@Transactional
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao tdao;
	@Override
	public void addTrainee(Trainee trainee) {
		tdao.addTrainee(trainee);
		
	}

	@Override
	public int delTrainee(int traineeId) {
		return tdao.delTrainee(traineeId);
	}

	@Override
	public Trainee modifyTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return tdao.modifyTrainee(trainee);
	}

	@Override
	public Trainee viewOne(int traineeId) {
		// TODO Auto-generated method stub
		return tdao.viewOne(traineeId);
	}

	@Override
	public List<Trainee> viewAll() {
		return tdao.viewAll();
	}

}
