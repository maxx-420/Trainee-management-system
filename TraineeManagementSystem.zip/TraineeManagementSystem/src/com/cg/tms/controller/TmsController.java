package com.cg.tms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



import com.cg.tms.entities.Trainee;
import com.cg.tms.service.TraineeService;



@Controller
public class TmsController {
	
	@Autowired
	TraineeService tser;
	
	@RequestMapping("start")
	 public String login(@RequestParam("uname") String uname,@RequestParam("pass") String pass,Model model){
		if(uname.equals("admin") && pass.equals("admin")){
			model.addAttribute("uname",uname);
			return "home";
		}else{
			String error= "Invalid UserName or PassWord";
			model.addAttribute("error",error);
			return "index";		
		}
		
	}
	
	//This is the add section
	@RequestMapping("addnew")
	public String addnew(Model model){
		Trainee tdetails = new Trainee();
		model.addAttribute("tdetails",tdetails);
		return "add";
		
	}
	
	@RequestMapping("add")
    public String add(@Valid @ModelAttribute("tdetails")Trainee tdetails,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("tdetails",tdetails);
			return "add";
		}else{
			tser.addTrainee(tdetails);
			model.addAttribute("tdetails",tdetails);
			return "success";
		}
    	
    	
    }
	
	//This is the Delete Section
	@RequestMapping("delview")
	public String delview(Model model) {
		List<Trainee> tdetails = tser.viewAll();
		model.addAttribute("tdetails", tdetails);
		return "delview";
		
	}
	
	@RequestMapping("del")
	public String del(@RequestParam("traineeId")Integer traineeId,Model model){
		int id= tser.delTrainee(traineeId);
		List<Trainee> tdetails = tser.viewAll();
		model.addAttribute("id",id);
		model.addAttribute("tdetails", tdetails);
		return "delview";
		
	}
	
	//This is the Modify section
	@RequestMapping("modifyview")
	public String modifyview(Model model) {
		List<Trainee> tdetails = tser.viewAll();
		model.addAttribute("tdetails", tdetails);
		return "modifyview";
		
	}
	
	@RequestMapping("modify")
	public String modify(@RequestParam("traineeId")Integer traineeId,Model model){
		Trainee trainee= tser.viewOne(traineeId);
		ArrayList<Trainee> traineeList= new ArrayList<Trainee>();
		traineeList.add(trainee);
		model.addAttribute("trainee",trainee);
		model.addAttribute("traineeList",traineeList);
		model.addAttribute("traineeId",traineeId);
		return "modify1";
		
	}
	
	@RequestMapping("modifyok")
	public String modifyok(@Valid @ModelAttribute("trainee")Trainee trainee,@RequestParam("id") Integer oldId,BindingResult res,Model model){
		int id=tser.delTrainee(oldId);
		Trainee tlist=tser.modifyTrainee(trainee);
		model.addAttribute("tlist",tlist);
		model.addAttribute("id",id);
		return "success";
		
	}
	
	
	//retrieve one
	@RequestMapping("viewoneview")
	public String viewoneview(Model model) {
		List<Trainee> tdetails = tser.viewAll();
		model.addAttribute("tdetails", tdetails);
		return "viewone";
		
	}
	
	@RequestMapping("viewone")
	public String viewone(@RequestParam("traineeId")Integer traineeId,Model model){
		List<Trainee> tdetails = tser.viewAll();
		model.addAttribute("tdetails", tdetails);
		Trainee trainee=tser.viewOne(traineeId);
		model.addAttribute("trainee",trainee);
		return "viewone";
		
	}

	//retrieve all
	@RequestMapping("viewall")
	public String viewall(Model model){
		List<Trainee> trainee = tser.viewAll();
		model.addAttribute("trainee",trainee);
		return "viewall";
	}
}
