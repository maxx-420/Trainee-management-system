package com.cg.tms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="trainee_158000")
public class Trainee {

	@Id
	@Column(name="traineeid")
	@NotNull(message="Trainee ID is mandatory")
	private Integer traineeId;
	
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="[A-Z a-z]{4,15}", message ="Name should contain min 5 and max 15 charcters")
	@Column(name="traineename")
	private String traineeName;
	
	@Column(name="traineedomain")
	private String traineeDomain;
	
	@Column(name="trineelocation")
	private String traineeLocation;

	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
	
	
	
}
