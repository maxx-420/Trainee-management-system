package com.cg.tms.dao;

import java.util.List;

import com.cg.tms.entities.Trainee;

public interface TraineeDao {
	public void addTrainee(Trainee trainee);
	public int delTrainee(int traineeId);
	public Trainee modifyTrainee(Trainee trainee);
	public Trainee viewOne(int traineeId);
	public List<Trainee> viewAll();
}
