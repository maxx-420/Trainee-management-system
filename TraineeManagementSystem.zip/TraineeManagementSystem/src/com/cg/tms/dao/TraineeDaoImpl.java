package com.cg.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.tms.entities.Trainee;

@Repository("tdao")

public class TraineeDaoImpl implements TraineeDao  {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public void addTrainee(Trainee trainee) {
		em.persist(trainee);	
	}

	@Override
	public int delTrainee(int traineeId) {
		Trainee trainee = em.find(Trainee.class,traineeId);
		
		em.remove(trainee);

		return traineeId;
	}

	@Override
	public Trainee modifyTrainee(Trainee trainee) {
		em.persist(trainee);
		return trainee;
	}

	@Override
	public Trainee viewOne(int traineeId) {
		Trainee trainee = em.find(Trainee.class,traineeId);
		return trainee;
	}

	@Override
	public List<Trainee> viewAll() {
		String jpql = "SELECT t FROM Trainee t";
		TypedQuery<Trainee> query = em.createQuery(jpql,Trainee.class);
		return query.getResultList();
	}

}
